# IBM STM Model 1

Simple implementation of the EM Algorithm, applied to IBM Model 1 for statistical machine translation.

This just trains a model, does not perform any translation.
